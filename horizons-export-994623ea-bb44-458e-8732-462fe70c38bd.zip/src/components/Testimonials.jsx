
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'María González',
    role: 'Empresaria',
    content: 'Excelente servicio y productos de calidad. Mi laptop llegó en perfectas condiciones y el soporte fue excepcional.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/150?img=1'
  },
  {
    name: 'Carlos Rodríguez',
    role: 'Diseñador',
    content: 'Los mejores precios del mercado. Encontré exactamente lo que buscaba y la entrega fue rapidísima.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/150?img=2'
  },
  {
    name: 'Ana Martínez',
    role: 'Estudiante',
    content: 'Increíble experiencia de compra. La atención al cliente es de primera y los productos superaron mis expectativas.',
    rating: 5,
    avatar: 'https://i.pravatar.cc/150?img=3'
  }
];

const Testimonials = () => {
  return (
    <section className="py-20">
      <div className="text-center mb-12">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4"
        >
          <span className="bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
            Lo que dicen nuestros clientes
          </span>
        </motion.h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {testimonials.map((testimonial, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="relative bg-gradient-to-b from-white/5 to-white/0 border border-white/10 rounded-2xl p-6 hover:shadow-2xl hover:shadow-cyan-500/10 transition-all"
          >
            <Quote className="absolute top-6 right-6 w-12 h-12 text-cyan-500/20" />

            <div className="flex items-center gap-4 mb-4">
              <img
                src={testimonial.avatar}
                alt={testimonial.name}
                className="w-12 h-12 rounded-full border-2 border-cyan-500/50"
              />
              <div>
                <p className="font-semibold text-white">{testimonial.name}</p>
                <p className="text-sm text-gray-400">{testimonial.role}</p>
              </div>
            </div>

            <div className="flex gap-1 mb-4">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-cyan-400 text-cyan-400" />
              ))}
            </div>

            <p className="text-gray-300">
              "{testimonial.content}"
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Testimonials;
