
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart as ShoppingCartIcon, Menu, X } from 'lucide-react';
import ShoppingCart from '@/components/ShoppingCart';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';

const Layout = ({ children }) => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cartItems } = useCart();
  const location = useLocation();

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const navItems = [
    { name: 'Inicio', path: '/' },
    { name: 'Productos', path: '/store' },
    { name: 'Acerca de', path: '/about' },
    { name: 'Contacto', path: '/contact' }
  ];

  const isActivePath = (path) => location.pathname === path;

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-black/95 backdrop-blur-md border-b border-white/10">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center font-bold text-black transition-transform group-hover:scale-110">
                N
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
                NexuzTech
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`relative text-sm font-medium transition-colors hover:text-cyan-400 ${
                    isActivePath(item.path) ? 'text-cyan-400' : 'text-gray-300'
                  }`}
                >
                  {item.name}
                  {isActivePath(item.path) && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute -bottom-6 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-400 to-blue-600"
                    />
                  )}
                </Link>
              ))}
            </div>

            {/* Cart & Mobile Menu */}
            <div className="flex items-center gap-4">
              <Button
                onClick={() => setIsCartOpen(true)}
                variant="ghost"
                size="icon"
                className="relative text-white hover:bg-white/10"
              >
                <ShoppingCartIcon size={20} />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gradient-to-r from-cyan-400 to-blue-600 text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Button>

              <Button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                variant="ghost"
                size="icon"
                className="md:hidden text-white hover:bg-white/10"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </Button>
            </div>
          </div>
        </nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-white/10 bg-black"
            >
              <div className="px-4 py-4 space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`block py-2 px-4 rounded-lg transition-colors ${
                      isActivePath(item.path)
                        ? 'bg-gradient-to-r from-cyan-500/10 to-blue-600/10 text-cyan-400'
                        : 'text-gray-300 hover:bg-white/5'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black border-t border-white/10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center font-bold text-black">
                  N
                </div>
                <span className="text-lg font-bold bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
                  NexuzTech
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                Tecnología de vanguardia para tu estilo de vida digital.
              </p>
            </div>

            <div>
              <span className="text-white font-semibold mb-4 block">Empresa</span>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Acerca de</Link></li>
                <li><Link to="/store" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Productos</Link></li>
                <li><Link to="/contact" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Contacto</Link></li>
              </ul>
            </div>

            <div>
              <span className="text-white font-semibold mb-4 block">Soporte</span>
              <ul className="space-y-2">
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Centro de ayuda</span></li>
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Envíos</span></li>
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Devoluciones</span></li>
              </ul>
            </div>

            <div>
              <span className="text-white font-semibold mb-4 block">Legal</span>
              <ul className="space-y-2">
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Privacidad</span></li>
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Términos</span></li>
                <li><span className="text-gray-400 text-sm cursor-pointer hover:text-cyan-400 transition-colors">Cookies</span></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/10 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} NexuzTech. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>

      {/* Shopping Cart Sidebar */}
      <ShoppingCart isCartOpen={isCartOpen} setIsCartOpen={setIsCartOpen} />
    </div>
  );
};

export default Layout;
