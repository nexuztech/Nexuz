
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: '¿Cuál es el tiempo de entrega?',
    answer: 'Nuestro tiempo de entrega es de 24-48 horas para la mayoría de productos en stock. Para productos especiales, el tiempo puede variar entre 3-5 días hábiles.'
  },
  {
    question: '¿Ofrecen garantía en los productos?',
    answer: 'Sí, todos nuestros productos incluyen garantía del fabricante. Además, ofrecemos garantía extendida opcional para mayor tranquilidad.'
  },
  {
    question: '¿Puedo devolver un producto?',
    answer: 'Sí, aceptamos devoluciones dentro de los primeros 30 días de la compra, siempre que el producto esté en perfectas condiciones y con su empaque original.'
  },
  {
    question: '¿Qué métodos de pago aceptan?',
    answer: 'Aceptamos tarjetas de crédito, débito, transferencias bancarias y pagos en efectivo contra entrega en algunas zonas.'
  },
  {
    question: '¿Hacen envíos internacionales?',
    answer: 'Actualmente realizamos envíos a todo el país. Los envíos internacionales están disponibles para pedidos especiales.'
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <section className="py-20">
      <div className="text-center mb-12">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4"
        >
          <span className="bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
            Preguntas Frecuentes
          </span>
        </motion.h2>
      </div>

      <div className="max-w-3xl mx-auto space-y-4">
        {faqs.map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.05 }}
          >
            <button
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full text-left bg-gradient-to-b from-white/5 to-white/0 border border-white/10 rounded-xl p-6 hover:border-cyan-500/30 transition-all"
            >
              <div className="flex justify-between items-center">
                <span className="font-semibold text-white pr-8">{faq.question}</span>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                </motion.div>
              </div>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="text-gray-400 mt-4">
                      {faq.answer}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default FAQ;
