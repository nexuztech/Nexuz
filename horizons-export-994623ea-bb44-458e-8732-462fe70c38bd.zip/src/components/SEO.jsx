
import React from 'react';
import { Helmet } from 'react-helmet';

const SEO = ({ 
  title = "NexuzTech - Tecnología de Vanguardia", 
  description = "Descubre los mejores gadgets y dispositivos tech. Calidad, precio y soporte excepcional.",
  image = "https://images.unsplash.com/photo-1610802846803-c5c04c29b2b5?w=1200&h=630&fit=crop",
  url = window.location.href,
  type = "website"
}) => {
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      
      {/* Open Graph */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:url" content={url} />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      
      {/* Canonical */}
      <link rel="canonical" href={url} />
    </Helmet>
  );
};

export default SEO;
