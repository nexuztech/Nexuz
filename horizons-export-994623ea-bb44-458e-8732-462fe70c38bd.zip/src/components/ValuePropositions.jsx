
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, DollarSign, Headphones, Truck } from 'lucide-react';

const values = [
  {
    icon: Shield,
    title: 'Calidad Garantizada',
    description: 'Productos certificados y garantía extendida en todos nuestros dispositivos.'
  },
  {
    icon: DollarSign,
    title: 'Mejores Precios',
    description: 'Precios competitivos y promociones exclusivas para nuestros clientes.'
  },
  {
    icon: Headphones,
    title: 'Soporte 24/7',
    description: 'Equipo de expertos disponible para ayudarte en todo momento.'
  },
  {
    icon: Truck,
    title: 'Envío Rápido',
    description: 'Entrega express en 24-48 horas a todo el país.'
  }
];

const ValuePropositions = () => {
  return (
    <section className="py-20">
      <div className="text-center mb-12">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4"
        >
          <span className="bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
            ¿Por qué elegir NexuzTech?
          </span>
        </motion.h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {values.map((value, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="group text-center"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 mb-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 group-hover:scale-110 transition-transform">
              <value.icon className="w-8 h-8 text-cyan-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
              {value.title}
            </h3>
            <p className="text-gray-400">
              {value.description}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default ValuePropositions;
