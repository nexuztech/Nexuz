
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { CheckCircle, Package, Home, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SEO from '@/components/SEO';

const CheckoutSuccess = () => {
  const orderNumber = Math.random().toString(36).substring(2, 10).toUpperCase();
  const orderDate = new Date().toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  useEffect(() => {
    const confetti = () => {
      const colors = ['#06b6d4', '#3b82f6', '#8b5cf6'];
      const particleCount = 50;

      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.style.position = 'fixed';
        particle.style.width = '10px';
        particle.style.height = '10px';
        particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        particle.style.left = Math.random() * window.innerWidth + 'px';
        particle.style.top = '-10px';
        particle.style.borderRadius = '50%';
        particle.style.pointerEvents = 'none';
        particle.style.zIndex = '9999';
        document.body.appendChild(particle);

        const duration = 2000 + Math.random() * 1000;
        const rotate = Math.random() * 360;

        particle.animate([
          { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
          { transform: `translateY(${window.innerHeight}px) rotate(${rotate}deg)`, opacity: 0 }
        ], {
          duration: duration,
          easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
        }).onfinish = () => particle.remove();
      }
    };

    confetti();
  }, []);

  return (
    <>
      <SEO
        title="¡Compra Exitosa! - NexuzTech"
        description="Tu pedido ha sido confirmado. Gracias por tu compra en NexuzTech."
      />

      <div className="max-w-3xl mx-auto py-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="inline-flex items-center justify-center w-24 h-24 mb-6 rounded-full bg-gradient-to-br from-green-400 to-green-600"
          >
            <CheckCircle className="w-12 h-12 text-white" />
          </motion.div>

          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
              ¡Gracias por tu compra!
            </span>
          </h1>

          <p className="text-xl text-gray-300">
            Tu pedido ha sido confirmado exitosamente
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-b from-white/5 to-white/0 border border-white/10 rounded-2xl p-8 mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <p className="text-gray-400 text-sm mb-1">Número de Orden</p>
              <p className="text-white font-bold text-xl">#{orderNumber}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-1">Fecha</p>
              <p className="text-white font-bold text-xl">{orderDate}</p>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-2">Entrega Estimada</h3>
                <p className="text-gray-400">
                  Tu pedido llegará en <span className="text-cyan-400 font-semibold">2-3 días hábiles</span>
                </p>
                <p className="text-gray-400 text-sm mt-2">
                  Recibirás un correo electrónico con el número de seguimiento una vez que tu pedido sea enviado.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <Link to="/" className="flex-1">
            <Button
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-6"
            >
              <Home className="mr-2 h-5 w-5" />
              Volver al Inicio
            </Button>
          </Link>
          <Link to="/store" className="flex-1">
            <Button
              variant="outline"
              className="w-full border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 py-6"
            >
              <ShoppingBag className="mr-2 h-5 w-5" />
              Continuar Comprando
            </Button>
          </Link>
        </motion.div>
      </div>
    </>
  );
};

export default CheckoutSuccess;
