
import React from 'react';
import SEO from '@/components/SEO';
import HeroSection from '@/components/HeroSection';
import FeaturedProducts from '@/components/FeaturedProducts';
import ValuePropositions from '@/components/ValuePropositions';
import Newsletter from '@/components/Newsletter';
import Testimonials from '@/components/Testimonials';
import FAQ from '@/components/FAQ';

const HomePage = () => {
  return (
    <>
      <SEO
        title="NexuzTech - Tecnología de Vanguardia | Los Mejores Gadgets y Dispositivos Tech"
        description="Descubre los mejores gadgets y dispositivos tech en NexuzTech. Calidad garantizada, mejores precios, soporte 24/7 y envío rápido."
        url={window.location.href}
      />

      <div className="-mt-8">
        <HeroSection />
      </div>

      <FeaturedProducts />
      <ValuePropositions />
      <Testimonials />
      <Newsletter />
      <FAQ />
    </>
  );
};

export default HomePage;
