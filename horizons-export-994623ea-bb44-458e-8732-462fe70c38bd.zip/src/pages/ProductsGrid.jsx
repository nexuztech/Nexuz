
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Loader2, SlidersHorizontal } from 'lucide-react';
import SEO from '@/components/SEO';
import ProductsList from '@/components/ProductsList';
import { Button } from '@/components/ui/button';
import { getProducts, getProductQuantities } from '@/api/EcommerceApi';

const ProductsGrid = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const productsResponse = await getProducts();

        if (productsResponse.products.length > 0) {
          const productIds = productsResponse.products.map(p => p.id);
          const quantitiesResponse = await getProductQuantities({
            fields: 'inventory_quantity',
            product_ids: productIds
          });

          const variantQuantityMap = new Map();
          quantitiesResponse.variants.forEach(variant => {
            variantQuantityMap.set(variant.id, variant.inventory_quantity);
          });

          const productsWithQuantities = productsResponse.products.map(product => ({
            ...product,
            variants: product.variants.map(variant => ({
              ...variant,
              inventory_quantity: variantQuantityMap.get(variant.id) ?? variant.inventory_quantity
            }))
          }));

          setProducts(productsWithQuantities);
        }
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const sortedProducts = useMemo(() => {
    const sorted = [...products];

    switch (sortBy) {
      case 'price-low':
        return sorted.sort((a, b) => {
          const priceA = a.variants[0]?.sale_price_in_cents ?? a.variants[0]?.price_in_cents ?? 0;
          const priceB = b.variants[0]?.sale_price_in_cents ?? b.variants[0]?.price_in_cents ?? 0;
          return priceA - priceB;
        });
      case 'price-high':
        return sorted.sort((a, b) => {
          const priceA = a.variants[0]?.sale_price_in_cents ?? a.variants[0]?.price_in_cents ?? 0;
          const priceB = b.variants[0]?.sale_price_in_cents ?? b.variants[0]?.price_in_cents ?? 0;
          return priceB - priceA;
        });
      case 'name':
        return sorted.sort((a, b) => a.title.localeCompare(b.title));
      case 'newest':
      default:
        return sorted;
    }
  }, [products, sortBy]);

  if (loading) {
    return (
      <>
        <SEO
          title="Productos - NexuzTech"
          description="Explora nuestra colección completa de productos tech y gadgets"
        />
        <div className="flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-16 w-16 text-cyan-400 animate-spin" />
        </div>
      </>
    );
  }

  return (
    <>
      <SEO
        title="Todos los Productos - NexuzTech"
        description="Explora nuestra colección completa de gadgets y dispositivos tech. Los mejores productos con garantía y envío rápido."
      />

      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold mb-2">
              <span className="bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
                Todos los Productos
              </span>
            </h1>
            <p className="text-gray-400">
              {products.length} productos disponibles
            </p>
          </div>

          <div className="flex items-center gap-4">
            <Button
              onClick={() => setShowFilters(!showFilters)}
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10"
            >
              <SlidersHorizontal className="mr-2 h-4 w-4" />
              Filtros
            </Button>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 bg-black/50 border border-white/20 rounded-lg text-white focus:outline-none focus:border-cyan-500 transition-colors"
            >
              <option value="newest">Más Recientes</option>
              <option value="price-low">Precio: Menor a Mayor</option>
              <option value="price-high">Precio: Mayor a Menor</option>
              <option value="name">Nombre A-Z</option>
            </select>
          </div>
        </motion.div>

        {/* Products Grid */}
        {sortedProducts.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <p className="text-gray-400 text-lg">No hay productos disponibles en este momento.</p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {sortedProducts.map((product, index) => {
              const displayVariant = product.variants[0];
              const hasSale = displayVariant?.sale_price_in_cents !== null;
              const displayPrice = hasSale ? displayVariant.sale_price_formatted : displayVariant.price_formatted;

              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <ProductCard product={product} displayPrice={displayPrice} hasSale={hasSale} />
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
};

const ProductCard = ({ product, displayPrice, hasSale }) => {
  return (
    <a href={`/product/${product.id}`} className="block">
      <div className="group relative bg-gradient-to-b from-white/5 to-white/0 border border-white/10 rounded-2xl overflow-hidden hover:shadow-2xl hover:shadow-cyan-500/20 transition-all duration-300 hover:-translate-y-2">
        <div className="relative overflow-hidden">
          <img
            src={product.image || "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMzc0MTUxIi8+CiAgPHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzlDQTNBRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pgo8L3N2Zz4K"}
            alt={product.title}
            className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          {product.ribbon_text && (
            <div className="absolute top-4 left-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full">
              {product.ribbon_text}
            </div>
          )}
          <div className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-sm text-cyan-400 font-bold px-3 py-1 rounded-full">
            {displayPrice}
          </div>
        </div>

        <div className="p-6">
          <h3 className="text-lg font-bold text-white mb-2 truncate group-hover:text-cyan-400 transition-colors">
            {product.title}
          </h3>
          <p className="text-sm text-gray-400 line-clamp-2">
            {product.subtitle || 'Descubre este increíble producto'}
          </p>
        </div>
      </div>
    </a>
  );
};

export default ProductsGrid;
