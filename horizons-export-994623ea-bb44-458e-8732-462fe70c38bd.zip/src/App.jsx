
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { CartProvider } from '@/hooks/useCart';
import { Toaster } from '@/components/ui/toaster';
import Layout from '@/components/Layout';
import HomePage from '@/pages/HomePage';
import ProductsGrid from '@/pages/ProductsGrid';
import ProductDetailPage from '@/pages/ProductDetailPage';
import CheckoutSuccess from '@/pages/CheckoutSuccess';

const PageTransition = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
};

const PlaceholderPage = ({ title }) => (
  <PageTransition>
    <div className="text-center py-20">
      <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
        {title}
      </h1>
      <p className="text-gray-400">Esta página estará disponible próximamente.</p>
    </div>
  </PageTransition>
);

function App() {
  return (
    <Router>
      <CartProvider>
        <Layout>
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<PageTransition><HomePage /></PageTransition>} />
              <Route path="/store" element={<PageTransition><ProductsGrid /></PageTransition>} />
              <Route path="/product/:id" element={<PageTransition><ProductDetailPage /></PageTransition>} />
              <Route path="/success" element={<PageTransition><CheckoutSuccess /></PageTransition>} />
              <Route path="/about" element={<PlaceholderPage title="Acerca de NexuzTech" />} />
              <Route path="/contact" element={<PlaceholderPage title="Contacto" />} />
            </Routes>
          </AnimatePresence>
        </Layout>
        <Toaster />
      </CartProvider>
    </Router>
  );
}

export default App;
